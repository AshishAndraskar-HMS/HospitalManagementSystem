import React from 'react'

const InvalidPage = () => {
  return (
    <div >
    <div style={{color:"red",backgroundColor:"white",fontSize:"100px"}}>Invalid page !!</div>
   
   
   <a style={{fontSize:"30px",color:"blue",fontWeight:"bold"}} href="/">... HOME...</a>
  
  
  
  </div>
  )
}

export default InvalidPage